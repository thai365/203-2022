module abc {
	requires java.desktop;
}